# Django Custom Commands

Read the blog post: [How to Create Custom Django Management Commands](https://simpleisbetterthancomplex.com/tutorial/2018/08/27/how-to-create-custom-django-management-commands.html)

[Jump to management commands sources](https://github.com/sibtc/django-custom-commands/tree/master/core/management/commands)
