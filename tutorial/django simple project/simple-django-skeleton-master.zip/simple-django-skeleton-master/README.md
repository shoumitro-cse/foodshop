# simple-django-skeleton
