# Urban Train

This Django project is just a small example to illustrate the deployment of a Django application using a Virtual Private Server.
