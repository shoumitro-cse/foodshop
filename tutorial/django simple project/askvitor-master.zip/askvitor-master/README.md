# Ask Vitor

This is the repository where I share the code used in Q&A posts from the blog [simpleisbetterthancomplex.com](https://simpleisbetterthancomplex.com).

# Questions

* [Ask Vitor #1: Getting form data to appear in URL and for use in the next view](https://github.com/sibtc/askvitor/tree/master/0001)
* [Ask Vitor #2: How to dynamically filter ModelChoice's queryset in a ModelForm?](https://github.com/sibtc/askvitor/tree/master/0002)
* [Ask Vitor #3: Mocking Emails](https://github.com/sibtc/askvitor/tree/master/0003)

# Have a question about Django?

Click in the link below and ask it!

[![Ask a Question](https://simpleisbetterthancomplex.com/img/btn_ask_a_question.png)](http://sibt.co/askvitor)
