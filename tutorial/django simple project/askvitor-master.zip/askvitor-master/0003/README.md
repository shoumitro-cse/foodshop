# Ask Vitor #3: Mocking Emails

[![Python Version](https://img.shields.io/badge/python-3.6.1-brightgreen.svg)](https://python.org)
[![Django Version](https://img.shields.io/badge/django-1.11.3-brightgreen.svg)](https://djangoproject.com)

Published at Jul 07, 2017

> I’m writing unit tests for my django app and I was wondering if there are any packages for mocking email or if there
> is any way I could mock sending and receiving of emails.
>
> Asked by Phillip Ahereza

`django` `test` `email`

[Read the answer](https://simpleisbetterthancomplex.com/questions/2017/07/07/mocking-emails.html)
