from django.apps import AppConfig


class PassengersConfig(AppConfig):
    name = 'passengers'
